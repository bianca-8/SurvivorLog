from flask_sqlalchemy import SQLAlchemy
from datetime import datetime

db = SQLAlchemy()

class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(20), unique=True, nullable=False)
    points = db.Column(db.Integer, default=0)
    zombie_kills = db.relationship('ZombieKill', backref='fighter', lazy=True)

    def __repr__(self):
        return f"User('{self.username}', '{self.points}')"

class ZombieKill(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    date_posted = db.Column(db.DateTime, nullable=False, default=datetime.utcnow)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    points_awarded = db.Column(db.Integer, nullable=False)

    def __repr__(self):
        return f"ZombieKill('{self.date_posted}', '{self.points_awarded}')"
