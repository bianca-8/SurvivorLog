document.getElementById('diaryForm').addEventListener('submit', function(e) {
    e.preventDefault();
    var entryText = document.getElementById('diaryEntry').value;
    if (entryText.trim() !== '') {
        saveEntry(entryText);
        document.getElementById('diaryEntry').value = '';
    } else {
        alert('Please write something before saving!');
    }
});

function saveEntry(text) {
    var entryDiv = document.createElement('div');
    entryDiv.classList.add('entry');
    entryDiv.textContent = text;
    document.getElementById('entries').appendChild(entryDiv);
}
