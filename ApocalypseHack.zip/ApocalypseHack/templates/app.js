const express = require('express');
const multer = require('multer');
const path = require('path');
const fs = require('fs');

const app = express();
const upload = multer({ dest: 'uploads/' });

app.use(express.static(path.join(__dirname, 'public')));
app.use(express.json());

app.post('/api/saveEntry', upload.single('file'), (req, res) => {
    const { text } = req.body;
    const file = req.file;
    // Save text entry to database
    // Process and save image file to server or cloud storage
    if (file) {
        const imageUrl = `/uploads/${file.filename}`;
        res.json({ message: 'Entry saved successfully', imageUrl });
    } else {
        res.json({ message: 'Entry saved successfully' });
    }
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`Server running on port ${PORT}`));
