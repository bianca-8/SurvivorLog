from flask import Flask, render_template, url_for, flash, redirect
from flask_sqlalchemy import SQLAlchemy
from models import db, User, ZombieKill
from config import Config

app = Flask(__name__)
app.config.from_object(Config)
db.init_app(app)

@app.route("/")
@app.route("/home")
def home():
    return render_template('home.html')

@app.route("/kill_zombie/<int:user_id>")
def kill_zombie(user_id):
    user = User.query.get(user_id)
    if user:
        points_awarded = 10  # For example, each zombie kill gives 10 points
        new_kill = ZombieKill(user_id=user.id, points_awarded=points_awarded)
        user.points += points_awarded
        db.session.add(new_kill)
        db.session.commit()
        flash('Zombie killed! Points awarded.', 'success')
    return redirect(url_for('home'))

@app.route("/leaderboard")
def leaderboard():
    users = User.query.order_by(User.points.desc()).all()
    return render_template('leaderboard.html', users=users)

if __name__ == "__main__":
    app.run(debug=True)
