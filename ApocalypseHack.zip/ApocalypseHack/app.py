from flask import Flask, render_template, request, redirect, url_for, flash, jsonify
from flask_sqlalchemy import SQLAlchemy
from datetime import datetime
import os
import base64

#, template_folder='templates'
app = Flask(__name__,template_folder='templates')
app.config['SECRET_KEY'] = 'you-will-never-guess'
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///site.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.config['UPLOAD_FOLDER'] = 'static/uploads'
db = SQLAlchemy(app)

class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(20), unique=True, nullable=False)
    points = db.Column(db.Integer, default=0)
    zombie_kills = db.relationship('ZombieKill', backref='fighter', lazy=True)

    def __repr__(self):
        return f"User('{self.username}', '{self.points}')"

class ZombieKill(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    date_posted = db.Column(db.DateTime, nullable=False, default=datetime.utcnow)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    points_awarded = db.Column(db.Integer, nullable=False)

    def __repr__(self):
        return f"ZombieKill('{self.date_posted}', '{self.points_awarded}')"

@app.route("/")
@app.route("/home")
def home():
    return render_template('home.html')

@app.route("/kill_zombie/<int:user_id>")
def kill_zombie(user_id):
    user = User.query.get(user_id)
    if user:
        points_awarded = 10  # For example, each zombie kill gives 10 points
        new_kill = ZombieKill(user_id=user.id, points_awarded=points_awarded)
        user.points += points_awarded
        db.session.add(new_kill)
        db.session.commit()
        flash('Zombie killed! Points awarded.', 'success')
    return redirect(url_for('home'))

@app.route("/leaderboard")
def leaderboard():
    users = User.query.order_by(User.points.desc()).all()
    return render_template('leaderboard.html', users=users)

@app.route('/journal')
def journal():
    return render_template('journal.html')

@app.route('/journal_log', methods=['GET'])
def journal_log():
    print("hjkhjhkjh")
    diary_entry = request.args.get('diaryEntry')
    with open('diary_entries.txt', 'a') as f:
        f.write(f'{diary_entry}\n')
        f.write("This is Test Data")
    return render_template('journal_log.html')

@app.route('/api/uploadPhoto', methods=['GET'])
def upload_photo():
    image_name = request.args.get('name')
    base64_image = request.args.get('image')

    if not image_name or not base64_image:
        return jsonify({'error': 'Invalid request'}), 400

    try:

        image_data = base64.b64decode(base64_image)
        file_path = os.path.join(app.config['UPLOAD_FOLDER'], image_name)
        with open(file_path, 'wb') as f:
            f.write(image_data)
        return jsonify({'imageUr1':url_for('static',filename=f'uploads/{image_name}')}) 
    except Exception as e:
        return jsonify({'error':str(e)}),500

if __name__ == "__main__":
    if not os.path.exists(app.config['UPLOAD_FOLDER']):
        os.makedirs(app.config['UPLOAD_FOLDER'])
    app.run(debug=True)
